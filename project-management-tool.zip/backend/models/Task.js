const mongoose = require('mongoose');
const taskSchema = new mongoose.Schema({ project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project' }, title: String, assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, status: String, comments: [{ user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, text: String }] });
module.exports = mongoose.model('Task', taskSchema);