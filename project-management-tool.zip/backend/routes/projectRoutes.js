const express = require('express'); const Project = require('../models/Project'); const router = express.Router();
router.post('/create', async (req, res) => { const { name, members } = req.body; const project = new Project({ name, members }); await project.save(); res.json(project); });
module.exports = router;