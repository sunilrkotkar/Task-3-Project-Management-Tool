const express = require('express'); const Task = require('../models/Task'); const router = express.Router();
router.post('/create', async (req, res) => { const { project, title, assignedTo, status } = req.body; const task = new Task({ project, title, assignedTo, status }); await task.save(); res.json(task); });
router.post('/comment', async (req, res) => { const { taskId, userId, text } = req.body; await Task.findByIdAndUpdate(taskId, { $push: { comments: { user: userId, text } } }); res.json({ message: 'Comment Added' }); });
module.exports = router;